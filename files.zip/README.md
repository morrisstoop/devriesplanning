# De Vries Planning — Opsplitsen

## Probleem
Je `index.html` is één enorm bestand (150KB+). GitHub heeft moeite met grote bestanden en het is lastig om aan te werken.

## Oplossing: Automatisch opsplitsen

### Stap 1: Download het script
Download `split_devries.py` naar dezelfde map als je `index.html`.

### Stap 2: Run het script
Open je terminal en run:
```bash
cd /pad/naar/je/devriesplanning
python3 split_devries.py
```

Dit maakt automatisch 4 bestanden:
- `index_new.html` — Alleen HTML structuur + CSS (~klein)
- `data.js` — Alle data (locaties, postcodes, planning)
- `heatmap.js` — Kaart + dagplanner logica
- `weekplanner.js` — Weekplanner + Gantt logica

### Stap 3: Test lokaal
Open `index_new.html` in je browser om te checken of alles werkt.

### Stap 4: Upload naar GitHub
1. Hernoem `index_new.html` → `index.html` (overschrijf de oude)
2. Upload alle 4 bestanden naar je repo
3. Activeer GitHub Pages (Settings → Pages → main branch)

### Stap 5: Samenwerken met Claude
Nu kun je per bestand werken:
- Wil je de kaart aanpassen? Deel alleen `heatmap.js`
- Wil je data updaten? Deel alleen `data.js`
- Wil je de weekplanner verbeteren? Deel alleen `weekplanner.js`

Geen "te groot" problemen meer!

## GitHub Pages
Na activatie is je site bereikbaar op:
```
https://morrisstoop.github.io/devriesplanning/
```
